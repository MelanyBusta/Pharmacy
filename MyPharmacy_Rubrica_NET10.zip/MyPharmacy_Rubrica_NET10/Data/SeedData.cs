using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using MyPharmacy.Models;

namespace MyPharmacy.Data;

public static class SeedData
{
    private static readonly (string Code, string Name)[] Permissions =
    {
        ("users.view", "Consultar usuarios"),
        ("users.create", "Crear usuarios"),
        ("users.edit", "Editar usuarios"),
        ("users.delete", "Eliminar usuarios"),
        ("roles.view", "Consultar roles"),
        ("roles.create", "Crear roles"),
        ("roles.edit", "Editar roles"),
        ("roles.delete", "Eliminar roles"),
        ("products.view", "Consultar productos"),
        ("products.create", "Crear productos"),
        ("products.edit", "Editar productos"),
        ("products.delete", "Eliminar productos"),
        ("branches.view", "Consultar sucursales"),
        ("branches.create", "Crear sucursales"),
        ("branches.edit", "Editar sucursales"),
        ("branches.delete", "Eliminar sucursales"),
        ("suppliers.view", "Consultar proveedores"),
        ("suppliers.create", "Crear proveedores"),
        ("suppliers.edit", "Editar proveedores"),
        ("suppliers.delete", "Eliminar proveedores")
    };

    public static async Task InitializeAsync(IServiceProvider services)
    {
        var db = services.GetRequiredService<ApplicationDbContext>();
        var roleManager = services.GetRequiredService<RoleManager<ApplicationRole>>();
        var userManager = services.GetRequiredService<UserManager<ApplicationUser>>();

        foreach (var item in Permissions)
        {
            if (!await db.Permissions.AnyAsync(p => p.Code == item.Code))
                db.Permissions.Add(new Permission { Code = item.Code, Name = item.Name });
        }
        await db.SaveChangesAsync();

        foreach (var roleName in new[] { "Administrador", "Empleado", "Cliente" })
        {
            if (!await roleManager.RoleExistsAsync(roleName))
                await roleManager.CreateAsync(new ApplicationRole { Name = roleName });
        }

        var adminRole = await roleManager.FindByNameAsync("Administrador");
        if (adminRole != null)
        {
            var allPermissionIds = await db.Permissions.Select(p => p.Id).ToListAsync();
            var existingIds = await db.RolePermissions.Where(x => x.RoleId == adminRole.Id)
                .Select(x => x.PermissionId).ToListAsync();

            foreach (var id in allPermissionIds.Except(existingIds))
                db.RolePermissions.Add(new RolePermission { RoleId = adminRole.Id, PermissionId = id });
            await db.SaveChangesAsync();
        }

        const string adminEmail = "admin@mypharmacy.local";
        var admin = await userManager.FindByEmailAsync(adminEmail);
        if (admin == null)
        {
            admin = new ApplicationUser
            {
                UserName = adminEmail,
                Email = adminEmail,
                FirstName = "Administrador",
                LastName = "Sistema",
                EmailConfirmed = true,
                IsActive = true
            };

            var result = await userManager.CreateAsync(admin, "Admin12345");
            if (result.Succeeded)
                await userManager.AddToRoleAsync(admin, "Administrador");
        }
    }
}
