using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MyPharmacy.Data;
using MyPharmacy.Models;
using MyPharmacy.Security;
using System.ComponentModel.DataAnnotations;

namespace MyPharmacy.Controllers;

[Route("Users")]
public class UsersController : Controller
{
    private readonly UserManager<ApplicationUser> _users;
    private readonly RoleManager<ApplicationRole> _roles;
    private readonly ApplicationDbContext _db;

    public UsersController(UserManager<ApplicationUser> users, RoleManager<ApplicationRole> roles, ApplicationDbContext db)
    { _users = users; _roles = roles; _db = db; }

    [HasPermission("users.view")]
    [HttpGet("")]
    public async Task<IActionResult> Index() => View(await _users.Users.OrderBy(x => x.LastName).ToListAsync());

    [HasPermission("users.create")]
    [HttpGet("Create")]
    public async Task<IActionResult> Create()
    {
        ViewBag.Roles = await _roles.Roles.OrderBy(x => x.Name).ToListAsync();
        return View(new UserCreateViewModel());
    }

    [HasPermission("users.create")]
    [HttpPost("Create"), ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(UserCreateViewModel model)
    {
        ViewBag.Roles = await _roles.Roles.OrderBy(x => x.Name).ToListAsync();
        if (!ModelState.IsValid) return View(model);

        var user = new ApplicationUser {
            UserName = model.Email, Email = model.Email, FirstName = model.FirstName,
            LastName = model.LastName, PhoneNumber = model.PhoneNumber,
            EmailConfirmed = true, IsActive = true
        };
        var created = await _users.CreateAsync(user, model.Password);
        if (!created.Succeeded)
        {
            foreach (var e in created.Errors) ModelState.AddModelError("", e.Description);
            return View(model);
        }

        if (model.RoleNames.Count > 0)
        {
            var validRoles = await _roles.Roles.Where(r => model.RoleNames.Contains(r.Name!))
                .Select(r => r.Name!).ToListAsync();
            var roleResult = await _users.AddToRolesAsync(user, validRoles);
            if (!roleResult.Succeeded)
            {
                await _users.DeleteAsync(user);
                foreach (var e in roleResult.Errors) ModelState.AddModelError("", e.Description);
                return View(model);
            }
        }
        return RedirectToAction(nameof(Index));
    }

    [HasPermission("users.edit")]
    [HttpGet("Edit/{id:int}")]
    public async Task<IActionResult> Edit(int id)
    {
        var user = await _users.FindByIdAsync(id.ToString());
        if (user == null) return NotFound();
        ViewBag.Roles = await _roles.Roles.OrderBy(x => x.Name).ToListAsync();
        return View(new UserEditViewModel {
            Id = id, FirstName = user.FirstName, LastName = user.LastName,
            Email = user.Email ?? "", PhoneNumber = user.PhoneNumber,
            IsActive = user.IsActive, RoleNames = (await _users.GetRolesAsync(user)).ToList()
        });
    }

    [HasPermission("users.edit")]
    [HttpPost("Edit/{id:int}"), ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, UserEditViewModel model)
    {
        ViewBag.Roles = await _roles.Roles.OrderBy(x => x.Name).ToListAsync();
        if (id != model.Id) return BadRequest();
        if (!ModelState.IsValid) return View(model);
        var user = await _users.FindByIdAsync(id.ToString());
        if (user == null) return NotFound();

        var emailOwner = await _users.FindByEmailAsync(model.Email);
        if (emailOwner != null && emailOwner.Id != id)
        {
            ModelState.AddModelError(nameof(model.Email), "Ese correo ya está registrado.");
            return View(model);
        }

        user.FirstName = model.FirstName;
        user.LastName = model.LastName;
        user.Email = model.Email;
        user.UserName = model.Email;
        user.PhoneNumber = model.PhoneNumber;
        user.IsActive = model.IsActive;
        var update = await _users.UpdateAsync(user);
        if (!update.Succeeded)
        {
            foreach (var e in update.Errors) ModelState.AddModelError("", e.Description);
            return View(model);
        }

        var currentRoles = await _users.GetRolesAsync(user);
        await _users.RemoveFromRolesAsync(user, currentRoles);
        if (model.RoleNames.Count > 0)
            await _users.AddToRolesAsync(user, model.RoleNames.Distinct());

        return RedirectToAction(nameof(Index));
    }

    [HasPermission("users.delete")]
    [HttpPost("Deactivate/{id:int}"), ValidateAntiForgeryToken]
    public async Task<IActionResult> Deactivate(int id)
    {
        var user = await _users.FindByIdAsync(id.ToString());
        if (user == null) return NotFound();
        user.IsActive = false;
        await _users.UpdateAsync(user);
        return RedirectToAction(nameof(Index));
    }
}

public class UserCreateViewModel
{
    [Required, StringLength(80)] public string FirstName { get; set; } = "";
    [Required, StringLength(80)] public string LastName { get; set; } = "";
    [Required, EmailAddress] public string Email { get; set; } = "";
    [Phone] public string? PhoneNumber { get; set; }
    [Required, MinLength(8)] public string Password { get; set; } = "";
    public List<string> RoleNames { get; set; } = new();
}

public class UserEditViewModel
{
    public int Id { get; set; }
    [Required, StringLength(80)] public string FirstName { get; set; } = "";
    [Required, StringLength(80)] public string LastName { get; set; } = "";
    [Required, EmailAddress] public string Email { get; set; } = "";
    [Phone] public string? PhoneNumber { get; set; }
    public bool IsActive { get; set; }
    public List<string> RoleNames { get; set; } = new();
}
