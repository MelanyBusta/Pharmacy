using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MyPharmacy.Data;
using MyPharmacy.Models;
using MyPharmacy.Security;
using System.ComponentModel.DataAnnotations;

namespace MyPharmacy.Controllers;

[Route("Roles")]
public class RolesController : Controller
{
    private readonly ApplicationDbContext _db;
    public RolesController(ApplicationDbContext db) => _db = db;

    [HasPermission("roles.view")]
    [HttpGet("")]
    public async Task<IActionResult> Index() =>
        View(await _db.Roles.Include(r => r.RolePermissions).ThenInclude(rp => rp.Permission)
            .OrderBy(r => r.Name).ToListAsync());

    [HasPermission("roles.create")]
    [HttpGet("Create")]
    public async Task<IActionResult> Create()
    {
        ViewBag.Permissions = await _db.Permissions.OrderBy(p => p.Name).ToListAsync();
        return View(new RoleViewModel());
    }

    [HasPermission("roles.create")]
    [HttpPost("Create"), ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(RoleViewModel model)
    {
        ViewBag.Permissions = await _db.Permissions.OrderBy(p => p.Name).ToListAsync();
        if (!ModelState.IsValid) return View(model);
        if (await _db.Roles.AnyAsync(r => r.Name == model.Name))
        {
            ModelState.AddModelError(nameof(model.Name), "Ya existe un rol con ese nombre.");
            return View(model);
        }

        var role = new ApplicationRole { Name = model.Name.Trim(), Description = model.Description };
        _db.Roles.Add(role);
        await _db.SaveChangesAsync();
        await SavePermissions(role.Id, model.PermissionIds);
        return RedirectToAction(nameof(Index));
    }

    [HasPermission("roles.edit")]
    [HttpGet("Edit/{id:int}")]
    public async Task<IActionResult> Edit(int id)
    {
        var role = await _db.Roles.Include(r => r.RolePermissions).FirstOrDefaultAsync(r => r.Id == id);
        if (role == null) return NotFound();
        ViewBag.Permissions = await _db.Permissions.OrderBy(p => p.Name).ToListAsync();
        return View(new RoleViewModel {
            Id = id, Name = role.Name ?? "", Description = role.Description,
            PermissionIds = role.RolePermissions.Select(x => x.PermissionId).ToList()
        });
    }

    [HasPermission("roles.edit")]
    [HttpPost("Edit/{id:int}"), ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, RoleViewModel model)
    {
        ViewBag.Permissions = await _db.Permissions.OrderBy(p => p.Name).ToListAsync();
        if (id != model.Id) return BadRequest();
        if (!ModelState.IsValid) return View(model);
        var role = await _db.Roles.FindAsync(id);
        if (role == null) return NotFound();
        if (await _db.Roles.AnyAsync(r => r.Id != id && r.Name == model.Name))
        {
            ModelState.AddModelError(nameof(model.Name), "Ya existe un rol con ese nombre.");
            return View(model);
        }
        role.Name = model.Name.Trim();
        role.Description = model.Description;
        await _db.SaveChangesAsync();
        await SavePermissions(id, model.PermissionIds);
        return RedirectToAction(nameof(Index));
    }

    private async Task SavePermissions(int roleId, IEnumerable<int> permissionIds)
    {
        var old = _db.RolePermissions.Where(x => x.RoleId == roleId);
        _db.RolePermissions.RemoveRange(old);
        var validIds = await _db.Permissions.Where(p => permissionIds.Contains(p.Id))
            .Select(p => p.Id).Distinct().ToListAsync();
        foreach (var permissionId in validIds)
            _db.RolePermissions.Add(new RolePermission { RoleId = roleId, PermissionId = permissionId });
        await _db.SaveChangesAsync();
    }
}

public class RoleViewModel
{
    public int Id { get; set; }
    [Required, StringLength(100)] public string Name { get; set; } = "";
    [StringLength(250)] public string? Description { get; set; }
    public List<int> PermissionIds { get; set; } = new();
}
